#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDataStream>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , socket(new QTcpSocket(this))
{
    ui->setupUi(this);

    // Подключаем сигналы сокета
    connect(socket, &QTcpSocket::connected, this, &MainWindow::onConnected);
    connect(socket, &QTcpSocket::readyRead, this, &MainWindow::onReadyRead);

    // Подключаемся к серверу
    socket->connectToHost("127.0.0.1", 12345);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::onConnected()
{
    qDebug() << "Подключено к серверу";
}

void MainWindow::onReadyRead()
{
    static QByteArray buffer;
    buffer += socket->readAll();

    QDataStream in(&buffer, QIODevice::ReadOnly);
    in.setVersion(QDataStream::Qt_6_0);

    // Пытаемся прочитать данные из буфера
    QString message;
    int clientCount;

    // Проверка на доступность данных (объём)
    if (in.status() == QDataStream::Ok) {
        in >> message >> clientCount;

        // Показываем в UI
        ui->labelMessage->setText("Сообщение: " + message);
        ui->labelCount->setText("Подключено клиентов: " + QString::number(clientCount));

        // Очищаем буфер после успешного чтения
        buffer.clear();
    } else {
        qDebug() << "Данные ещё не полные";
    }
}
