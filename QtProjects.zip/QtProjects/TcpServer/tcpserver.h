#ifndef TCPSERVER_H
#define TCPSERVER_H

#include <QTcpServer>
#include <QTcpSocket>
#include <QObject>
#include <QList>
#include <QString>

// Структура, которую будем передавать клиенту
struct Data {
    QString message;
    int clientCount;
};

class TcpServer : public QTcpServer
{
    Q_OBJECT

public:
    explicit TcpServer(QObject* parent = nullptr);

protected:
    void incomingConnection(qintptr socketDescriptor) override;

private:
    QList<QTcpSocket*> clients;
    void sendDataToClient(QTcpSocket* socket);
};

#endif // TCPSERVER_H
