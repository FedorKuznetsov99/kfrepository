#include "tcpserver.h"
#include <QDataStream>
#include <QDebug>

TcpServer::TcpServer(QObject* parent)
    : QTcpServer(parent)
{
    if (this->listen(QHostAddress::Any, 12345)) {
        qDebug() << "Сервер запущен на порту 12345";
    } else {
        qDebug() << "Не удалось запустить сервер!";
    }
}

void TcpServer::incomingConnection(qintptr socketDescriptor)
{
    QTcpSocket* clientSocket = new QTcpSocket(this);
    clientSocket->setSocketDescriptor(socketDescriptor);
    clients.append(clientSocket);

    connect(clientSocket, &QTcpSocket::disconnected, [this, clientSocket]() {
        clients.removeOne(clientSocket);
        clientSocket->deleteLater();
        qDebug() << "Клиент отключён";
    });

    sendDataToClient(clientSocket);
    qDebug() << "Клиент подключён. Текущее количество клиентов:" << clients.size();
}

void TcpServer::sendDataToClient(QTcpSocket* socket)
{
    if (!socket || !socket->isWritable())
        return;

    Data data;
    data.message = "Добро пожаловать!";
    data.clientCount = clients.size();

    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_6_0); // используем подходящую версию
    out << data.message << data.clientCount;

    socket->write(block);
}
